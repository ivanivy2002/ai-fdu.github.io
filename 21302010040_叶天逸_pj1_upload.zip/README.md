main 是主函数
fea 实现了多种特征工程
CMeasure 是将C(或lgC)作为参数测量正则化对Acc, Time的影响
KMeasure 是将K作为参数测量核函数对Acc, Time的影响
taskMeasure 测量不同model不同task的性能差异

fig 是所有输出的图片, out 记录了所有task的结果, data 记录了特征工程的结果npy